package bankmitarbeiter;

import java.io.Serializable;
import java.util.Observable;
import java.util.Observer;

import bank.Konto;

/**
 * Konstruktor der Klasse Bankangestellter mit den Parametern nachname und
 * vorname. setter und getter von: nachname und vorname
 * 
 * @author s0564264 Carmen Luu (s0564264@htw-berlin.de)
 *
 */

public class Bankangestellter implements Observer, Serializable {
	/**
	 * Vorname des Bankangestellten.
	 */
	private String vorname;

	/**
	 * Nachname des Bankangestellten.
	 */
	private String nachname;

	/**
	 * Konstruktor für einen Bankangestellten
	 * 
	 * @param nachname
	 *            Nachname des Bankangestellten
	 * @param vorname
	 *            Vorname des Bankangestellten
	 */
	public Bankangestellter(String nachname, String vorname) {
		this.nachname = nachname;
		this.vorname = vorname;
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	@Override
	public void update(Observable arg0, Object letzteEinAusZahlung) {
		if (letzteEinAusZahlung instanceof Konto) {
			Konto konto = (Konto) letzteEinAusZahlung;
			System.out.println("Bankangestellter: " + this.getNachname() + ", " + this.getVorname()
					+ " hat die Information erhalten, dass eine Einzahlung/Auszahlung in Höhe von "
					+ konto.getLetzteEinAusZahlung() + "€ auf das Konto " + konto.getIBAN() + " stattgefunden hat.\n");
		}
	}
}
