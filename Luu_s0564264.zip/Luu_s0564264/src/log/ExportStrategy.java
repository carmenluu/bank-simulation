package log;

/**
 * Export-Strategy-Interface.
 * 
 * @author s0564264 Carmen Luu (s0564264@htw-berlin.de)
 *
 */

public interface ExportStrategy {
	public void export(String message);
}
