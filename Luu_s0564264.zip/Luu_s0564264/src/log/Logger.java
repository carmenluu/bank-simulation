package log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;

/**
 * Logger.
 * 
 * @author s0564264 Carmen Luu (s0564264@htw-berlin.de)
 *
 */

public class Logger implements ExportStrategy {
	private static PrintWriter printwriterout;
	
	private static String getTime() {
		return LocalDateTime.now().toString();
	}

	private static Logger instance = new Logger();

	private Logger() {
	}

	public static Logger getInstance() {
		if (instance == null) {
			instance = new Logger();
		}
		return instance;
	}

	/**
	 * Export als txt-Datei
	 */
	@Override
	public void export(String message) {
		if(printwriterout == null) {
			FileOutputStream fileoutputstream;
			try {
				fileoutputstream = new FileOutputStream(new File("log.txt"), true);
				printwriterout = new PrintWriter(fileoutputstream);
				printwriterout.append(getTime() + ": Logger gestartet\n");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		printwriterout.append(getTime() + ": " + message + "\n");
		printwriterout.flush();
	}
	
	/**
	 * Console-Ausgabe
	 */
	public void consoleAusgabe(String message) {
		System.out.println(getTime() + ": " + message + "\n");
	}
}
