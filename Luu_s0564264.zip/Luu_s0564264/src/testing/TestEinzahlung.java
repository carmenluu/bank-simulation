package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import bank.Bank;

/**
 * Vorbedingungen für den dritten Testfall EINZAHLEN (es soll im Konto eine Methode zum Erhöhen des Guthabens existieren).
 * Überprüfung, ob Guthaben im Konto (IBAN) erhöht wird.
 * 
 * @author s0564264 Carmen Luu (s0564264@htw-berlin.de)
 *
 */

class TestEinzahlung {
	private Bank bank;
	
	/**
	 * Vorbedingungen für:
	 * Es soll im Konto eine Methode zum Erhöhen des Guthabens existieren.
	 */
	@BeforeEach
	void setUp() {
		bank = new Bank("Postbank Berlin", "Mariendorfer Damm", "422", 12107, "Berlin", 10010010, "PBNKDEFF");
		
		bank.vorstandAnlegen("Grunow", "Karl");
		bank.bankangestellenAnlegen("Grey", "Jonas");
		
		bank.privatKundeAnlegen(11, "frau", "Leona", "Til", "01.06.1987", "Lipschitzallee", "12", 12345, "Berlin",
				"306064768", "leona.til@privatkunde.de", 3);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 57", 10000, 11);
	}

	/**
	 * Überprüfung, ob Guthaben im Konto (IBAN) erhöht wird.
	 */
	@Test
	void test() {
		bank.geldEinzahlung("DE87 1005 0000 1076 1077 57", 600);
		double neuerKontostand = bank.getKontostandstandIBAN("DE87 1005 0000 1076 1077 57");
		assertEquals(10600, neuerKontostand);
	}
}
