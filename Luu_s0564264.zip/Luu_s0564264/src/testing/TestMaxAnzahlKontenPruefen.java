package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import bank.Bank;

/**
 * Vorbedingungen für den zweiten. Testfall (Die Regel mit der maximalen Anzahl von 10 Konten pro Kunde soll sichergestellt werden,
 * d. h. bei mehr als 10 Konten soll eine Exception in der Methode zum Hinzufügen von Konten zur Bank bzw. zum Kunden geworfen werden).
 * Überprüfung, ob beim hinzufügen eines 11 Kontos eine Exception geworfen wird.
 * 
 * @author s0564264 Carmen Luu (s0564264@htw-berlin.de)
 *
 */

class TestMaxAnzahlKontenPruefen {
	private Bank bank;
	
	/**
	 * Vorbedingungen für:
	 * Die Regel mit der maximalen Anzahl von 10 Konten pro Kunde soll sichergestellt werden,
	 * d. h. bei mehr als 10 Konten soll eine Exception in der Methode zum Hinzufügen von Konten zur Bank bzw. zum Kunden geworfen werden.
	 */
	@BeforeEach
	void setUp() {
		bank = new Bank("Postbank Berlin", "Mariendorfer Damm", "422", 12107, "Berlin", 10010010, "PBNKDEFF");
		
		bank.privatKundeAnlegen(11, "frau", "Leona", "Til", "01.06.1987", "Lipschitzallee", "12", 12345,
				"Berlin", "306064768", "leona.til@privatkunde.de", 10);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 57", 10000, 11);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 58", 2000, 11);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 59", 300, 11);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 60", 20000, 11);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 61", 3000, 11);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 62", 30000, 11);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 63", 300, 11);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 64", 40000, 11);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 65", 5000, 11);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 66", 600, 11);
	}

	/**
	 * Überprüfung, ob beim Hinzufügen eines 11 Kontos eine Exception geworfen wird.
	 */
	@Test
	void test() {		
		assertThrows(IndexOutOfBoundsException.class, () -> {
			bank.kontoAnlegen("DE87 1005 0000 1076 1077 67", 50000, 11);
		});
	}
}
