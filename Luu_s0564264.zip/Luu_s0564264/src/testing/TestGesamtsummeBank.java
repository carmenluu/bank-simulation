package testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import bank.Bank;

/**
 * Vorbedingungen für den ersten Testfall (Die Gesamtsumme über mindestens zwei Kunden und insgesamt 6 Konten soll in mindesten einem Testfall abgeprüft werden).
 * Überprüfung, ob die Gesamtsumme über alle Kunden und Konten richtig ist.
 * 
 * @author s0564264 Carmen Luu (s0564264@htw-berlin.de)
 *
 */

class TestGesamtsummeBank {
	private Bank bank;
	
	/**
	 * Vorbedingungen für: 
	 * Die Gesamtsumme über mindestens zwei Kunden und insgesamt 6 Konten soll in mindesten einem Testfall abgeprüft werden.
	 */
	@BeforeEach
	void setUp() {
		bank = new Bank("Postbank Berlin", "Mariendorfer Damm", "422", 12107, "Berlin", 10010010, "PBNKDEFF");
		
		bank.privatKundeAnlegen(11, "frau", "Leona", "Til", "01.06.1987", "Lipschitzallee", "12", 12345,
				"Berlin", "306064768", "leona.til@privatkunde.de", 3);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 57", 10000, 11);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 58", 2000, 11);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 59", 300, 11);
		
		bank.privatKundeAnlegen(14, "herr", "Thomas", "Caspary", "04.11.1991", "Lipschitzallee", "15",
				12345, "Berlin", "306064771", "thomas.caspary@privatkunde.de", 1);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 63", 300, 14);	
		
		bank.geschaeftskundeAnlegen(16, "Firmenname1", "Lipschitzallee", "17", 12345, "Berlin", "306064773",
				"firmenname1@geschaeftskunde.de", 2);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 67", 50000, 16);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 68", 6000, 16);
	}

	/**
	 * Überprüfung, ob die Gesamtsumme über alle Kunden und Konten richtig ist.
	 */
	@Test
	void test() {
		double gesamtsummeBank = bank.getTotalKontostandAllKonten();
		assertEquals(68600, gesamtsummeBank);
	}
}
