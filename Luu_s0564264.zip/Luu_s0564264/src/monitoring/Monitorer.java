package monitoring;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Calendar;

import bank.Bank;
import bank.Konto;
import kunde.Kunde;

/**
 * Hat einen Kontruktor der Klasse Monitorer (die Bank wird als Parameter übergeben.) Kann das aktuelle Datum und die Uhrzeit zurückgeben. 
 * Kann den Monitorer starten und stoppen.
 * 
 * @author s0564264 Carmen Luu (s0564264@htw-berlin.de)
 *
 */

public class Monitorer implements Runnable{
	private Bank bank;
	private boolean isRunning = false;
	private int interval = 1;
	private String timeStamp;
	private FileOutputStream fileoutputstream;
	private static PrintWriter printwriterout;

	/**
	 * Kontruktor der Klasse Monitorer. Die Bank wird als Parameter übergeben.
	 * 
	 * @param bank
	 */
	public Monitorer(Bank bank){
		this.bank = bank;
	}

	/**
	 * Gibt das aktuelle Datum und die Uhrzeit zurück.
	 * 
	 * @return timeStamp
	 */
	private String getTime(){
		timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
		return timeStamp;
	}

	/**
	 * Stoppt den Monitorer.
	 */
	public void stop(){
		isRunning = false;
	}

	/**
	 * Startet den Monitorer.
	 */
	public void run(){
		isRunning = true;

		while (isRunning == true) {
			try {
				if (printwriterout == null) {
					FileOutputStream fileoutputstream;
					try {
						fileoutputstream = new FileOutputStream(new File("monitoring.txt"), true);
						printwriterout = new PrintWriter(fileoutputstream);
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					}
				}
				printwriterout.append(getTime() + ": Die Bank verwaltet einen Gesamtkontostand in Höhe von "
						+ bank.getTotalKontostandAllKonten() + " Euro.\n");
				printwriterout.flush();

				Thread.sleep(interval * 10000);
			}catch (InterruptedException e){
				isRunning = false;
			}
		}
	}
}
