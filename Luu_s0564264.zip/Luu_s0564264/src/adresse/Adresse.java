package adresse;

import java.io.Serializable;

/**
 * Kontruktor der Klasse Adresse mit den Parametern adresszeile1, adresszeile2,
 * PLZ und ort; setter und getter von: adresszeile1, adresszeile2, PLZ, ort
 * 
 * @author s0564264 Carmen Luu (s0564264@htw-berlin.de)
 *
 */

public class Adresse implements Serializable {
	/**
	 * Adresszeile1.
	 */
	private String adresszeile1;

	/**
	 * Adresszeile2.
	 */
	private String adresszeile2;

	/**
	 * Postleitzahl.
	 */
	private int PLZ;

	/**
	 * Ort.
	 */
	private String ort;

	/**
	 * Kontruktor der Klasse Adresse mit den Parametern adresszeile1, adresszeile2, PLZ und Ort
	 * 
	 * @param adresszeile1
	 *            Gibt die 1. Adresszeile des Privat- oder Geschaeftskunden an
	 * @param adresszeile2
	 *            Gibt die 2. Adresszeile des Privat- oder Geschaeftskunden an
	 * @param PLZ
	 *            Gibt die PLZ des Privat- oder Geschaeftskunden an
	 * @param ort
	 *            Gibt den Ort des Privat- oder Geschaeftskunden an
	 */
	public Adresse(String adresszeile1, String adresszeile2, int PLZ, String ort) {
		this.adresszeile1 = adresszeile1;
		this.adresszeile2 = adresszeile2;
		this.PLZ = PLZ;
		this.ort = ort;
	}

	public String getAdresszeile1() {
		return adresszeile1;
	}

	public void setAdresszeile1(String adresszeile1) {
		this.adresszeile1 = adresszeile1;
	}

	public String getAdresszeile2() {
		return adresszeile2;
	}

	public void setAdresszeile2(String adresszeile2) {
		this.adresszeile2 = adresszeile2;
	}

	public int getPLZ() {
		return PLZ;
	}

	public void setPLZ(int pLZ) {
		PLZ = pLZ;
	}

	public String getOrt() {
		return ort;
	}

	public void setOrt(String ort) {
		this.ort = ort;
	}
}
