package bank;

import java.io.Serializable;

/**
 * Kann ein Konto erzeugen. setter und getter von: IBAN, kontostand, letzteEinAusZahlung
 * 
 * @author s0564264 Carmen Luu (s0564264@htw-berlin.de)
 *
 */

public class Konto implements Serializable {
	/**
	 * IBAN des Konto.
	 */
	private String IBAN;

	/**
	 * Kontostand des Kontos.
	 */
	private double kontostand;

	/**
	 * Kundennr des Privat- oder Geschaeftskunden.
	 */
	private int kundennr;
	
	/**
	 * Letzte Ein- oder Auszahlung des Kunden.
	 */
	private double letzteEinAusZahlung;

	/**
	 * Erzeugt ein Konto.
	 * 
	 * @param IBAN
	 *            des Kontos
	 * @param kontostand
	 *            Kontostand des Kontos
	 */
	public Konto(String IBAN, double kontostand, int kundennr) {
		this.IBAN = IBAN;
		this.kontostand = kontostand;
		this.kundennr = kundennr;
	}

	public String getIBAN() {
		return IBAN;
	}

	public void setIBAN(String iBAN) {
		IBAN = iBAN;
	}

	public double getKontostand() {
		return kontostand;
	}

	public void setKontostand(double kontostand) {
		this.kontostand = kontostand;
	}
	
	public double getLetzteEinAusZahlung() {
		return letzteEinAusZahlung;
	}

	public void setLetzteEinAusZahlung(double letzteEinAusZahlung) {
		this.letzteEinAusZahlung = letzteEinAusZahlung;
	}

	@Override
	public String toString() {
		return "	IBAN: " + this.IBAN + "\n" + "	Kontostand: " + this.kontostand + "€"
				+ "\n______________________________________________________________________________________________________________________________";
	}
}
