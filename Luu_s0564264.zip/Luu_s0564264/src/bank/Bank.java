package bank;

import adresse.Adresse;
import bankmitarbeiter.Bankangestellter;
import bankmitarbeiter.Vorstand;
import io.Ausgabe;
import kunde.Geschaeftskunde;
import kunde.Kunde;
import kunde.Privatkunde;
import log.Logger;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.*;

/**
 * Kann eine Bank erzeugen. HashMap fuer Konto/Konten anzeigen mithilfe der
 * IBAN. Kann einen Kunden dem Kunden-Array hinzufuegen. Ausgabe der Kunden.
 * Pruefung ob Kundennr vorhanden ist. Kann Privat- und Geschaeftskunden
 * anlegen. Kann ein Konto fuer einen Privat- und/oder Geschaeftskunden anlegen.
 * Kundeninformationen und Konto/Konten anzeigen mithilfe der Kundennr oder des
 * Name. Konto/Konten anzeigen mithilfe der IBAN. Alle Kunden sortiert nach
 * aufsteigender Kundenummer. Alle Kunden sortiert na
 * 
 * ch aufsteigendem Nachnamen
 * und nachrangig nach aufsteigendem Vornamen. Alle Konten unsortiert. Kann den
 * Kundentyp von einem Kunden ermitteln, sowie den gesamten Kontostand von allen
 * Konten von einem Kunden. Kann die aktuellen Bankdaten speichern und Daten aus
 * einem spezifischen Dateipfad laden. Export der Kunden sortiert nach Namen als
 * CSV-Datei moeglich. 
 * Setter und getter von: Name, BLZ, BIC, Kundenarray
 * 
 * @author s0564264 Carmen Luu (s0564264@htw-berlin.de)
 *
 */

public class Bank extends Observable implements Serializable {

	private static final long serialVersionUID = 1L;
	/**
	 * Name der Bank.
	 */
	private String name;

	/**
	 * Die Adresse der Bank.
	 */
	private Adresse adresse;

	/**
	 * BLZ der Bank.
	 */
	private int BLZ;

	/**
	 * BIC der Bank.
	 */
	private String BIC;

	/**
	 * Die Kunden der Bank.
	 */
	private ArrayList<Kunde> kundenarray = new ArrayList<Kunde>();
	
	/**
	 * Die Bankangestellten der Bank.
	 */
	private ArrayList<Bankangestellter> bankangestelltearray = new ArrayList<Bankangestellter>();

	/**
	 * HashMap beeinhalten als Key: IBAN und als Value: Konto
	 */
	private HashMap<String, Konto> hashmap = new HashMap();
	
	private ArrayList<Konto> konten = new ArrayList();

	/**
	 * Objekt von der Klasse Ausgabe.
	 */
	Ausgabe ausgabe = new Ausgabe();

	/**
	 * Scanner
	 */
	private Scanner sc = new Scanner(System.in);

	/**
	 * Modus von Log-Strategie
	 */
	private int mode;

	/**
	 * Auswahl von der Log-Strategie
	 */
	private int auswahl = 1;
	
	private boolean falscheEingabe = false;
	
	/**
	 * Erzeugt eine Bank.
	 * 
	 * @param name
	 *            Name der Bank
	 * @param adresszeile1
	 *            Adresszeile1 der Bank
	 * @param adresszeile2
	 *            Adresszeile2 der Bank
	 * @param PLZ
	 *            PLZ der Bank
	 * @param ort
	 *            Ort der Bank
	 * @param BLZ
	 *            BLZ der Bank
	 * @param BIC
	 *            BIC der Bank
	 */
	public Bank(String name, String adresszeile1, String adresszeile2, int PLZ, String ort, int BLZ, String BIC) {
		this.name = name;
		this.adresse = new Adresse(adresszeile1, adresszeile2, PLZ, ort);
		this.BLZ = BLZ;
		this.BIC = BIC;
	}
	
//	public Bank() {
//	}

	/**
	 * HashMap fuer Konto/Konten anzeigen mithilfe der IBAN.
	 * 
	 * @return hashmap
	 */
	public HashMap<String, Konto> generateMap() {
		for (Kunde kunde : kundenarray) {
			for (Konto konto : kunde.getKonten()) {
				String iban = konto.getIBAN();
				if (!hashmap.containsKey(iban)) {
					hashmap.put(iban, konto);
				}
			}
		}
		return hashmap;
	}

	/**
	 * Fuegt einen Kunden dem Kunden-Array hinzu.
	 * 
	 * @param kunde
	 *            Kunde der Bank
	 */
	public void addKunde(Kunde kunde) {
		kundenarray.add(kunde);
	}
	
	/**
	 * Gibt die Kunden aus.
	 */
	public void printKunden() {
		for (int i = 0; i < kundenarray.size(); i++) {
			System.out.println("\n" + kundenarray.get(i).toString());
			kundenarray.get(i).printKonto();
		}
	}

	/**
	 * Prueft ob Kundennr vorhanden ist.
	 * 
	 * @param kundennr
	 *            Kundennr des Kunden
	 * @return ob Kundennr vorhanden ist oder nicht
	 */
	public boolean isVorhandenKdnr(int kundennr) {
		try {
			for (int i = 0; i < kundenarray.size(); i++) {
				if (kundenarray.get(i).getKundennr() == kundennr) {
					ausgabe.printKdnrExistiertBereits();
					return true;
				}
			}
		} catch (Exception e) {
			ausgabe.printKdnrExistiertBereits();
		}
		return false;
	}

	/**
	 * Ermittelt den Kundentyp von einem Kunden.
	 * 
	 * @param kunde
	 *            Ein Kunde
	 * @return kundentyp Kundentyp des Kunden
	 */
	public String getKundentyp(Kunde kunde) {
		String kundentyp = null;
		if (kunde instanceof Privatkunde) {
			kundentyp = "Privatkunde";
		} else if (kunde instanceof Geschaeftskunde) {
			kundentyp = "Geschäftskunde";
		}
		return kundentyp;
	}

	/**
	 * Ermittelt den gesamten Kontostand von allen Konten von einem Kunden.
	 * 
	 * @param kunde
	 *            Ein Kunde
	 * @return gesamtKontostand Gesamtkontostand eines Kunden
	 */
	public double getTotalKontostand(Kunde kunde) {
		double gesamtKontostand = 0.0;
		for (Konto konto : kunde.getKonten()) {
			gesamtKontostand += konto.getKontostand();
		}
		return gesamtKontostand;
	}
	
	/**
	 * Legt einen Vorstand an und fügt ihn als Observer hinzu.
	 * @param nachname
	 * 			   Nachname des Vorstands
	 * @param vorname
	 * 			   Vorname des Vorstands
	 */
	public void vorstandAnlegen(String nachname, String vorname ) {
		Vorstand vorstand = new Vorstand(nachname, vorname);
		addObserver(vorstand);
	}
	
	/**
	 * Legt einen Bankangestellten an und fügt ihn als Observer und in die Bankangestellten-Arraylist hinzu.
	 * @param nachname
	 * 			   Nachname des Bankangestellten
	 * @param vorname
	 * 			   Vorname des Bankangestellten
	 */
	public void bankangestellenAnlegen(String nachname, String vorname) {
		Bankangestellter bankangestellter = new Bankangestellter(nachname, vorname);
		bankangestelltearray.add(bankangestellter);
		addObserver(bankangestellter);
	}
	
	/**
	 * CASE 1: PRIVATKUNDEN ANLEGEN. Legt einen Privatkunden an.
	 * 
	 * @param kundennr
	 *            Kundennr des Kunden
	 * @param anrede
	 *            Anrede des Kunden
	 * @param vorname
	 *            Vorname des Kunden
	 * @param nachname
	 *            Nachname des Kunden
	 * @param geburtsdatum
	 *            Geburtsdatum des Kunden
	 * @param adresszeile1
	 *            Adresszeile1 des Kunden
	 * @param adresszeile2
	 *            Adresszeile2 des Kunden
	 * @param PLZ
	 *            PLZ des Kunden
	 * @param ort
	 *            Ort des Kunden
	 * @param telefonnr
	 *            Telefonnr des Kunden
	 * @param emailadresse
	 *            E-Mail-Adresse des Kunden
	 * @param anzahlKonten
	 *            Anzahl der Konten des Kunden
	 */
	public void privatKundeAnlegen(int kundennr, String anrede, String vorname, String nachname, String geburtsdatum,
			String adresszeile1, String adresszeile2, int PLZ, String ort, String telefonnr, String emailadresse,
			int anzahlKonten) {
		Privatkunde privatkunde = new Privatkunde(kundennr, anrede, vorname, nachname, geburtsdatum, adresszeile1,
				adresszeile2, PLZ, ort, telefonnr, emailadresse, anzahlKonten);
		if (isVorhandenKdnr(kundennr) == false) {
			privatkunde.makeKonten(anzahlKonten);
			this.addKunde(privatkunde);
			ausgabe.printEingabenGespeichert();
		}
	}

	/**
	 * 
	 * @param privatkunde
	 */
	public void privatKundeAnlegen(Privatkunde privatkunde) {
		if (isVorhandenKdnr(privatkunde.getKundennr()) == false) {
			privatkunde.makeKonten(privatkunde.getMaxKonten());
			this.addKunde(privatkunde);
			ausgabe.printEingabenGespeichert();
		}
	}

	/**
	 * CASE 2: GESCHAEFTSKUNDE ANLEGEN. Legt einen Geschaeftskunden an.
	 * 
	 * @param kundennr
	 *            Kundennr des Geschaeftskunden
	 * @param firmenname
	 *            Firmenname des Geschaeftskunden
	 * @param adresszeile1
	 *            Adresszeile1 des Geschaeftskunden
	 * @param adresszeile2
	 *            Adresszeile2 des Geschaeftskunden
	 * @param PLZ
	 *            PLZ des Geschaeftskunden
	 * @param ort
	 *            Ort des Geschaeftskunden
	 * @param telefonnr
	 *            Telefonnr des Geschaeftskunden
	 * @param emailadresse
	 *            E-Mail-Adresse des Geschaeftskunden
	 * @param anzahlKonten
	 *            Anzahl der Konten des Geschaeftskunden
	 */
	public void geschaeftskundeAnlegen(int kundennr, String firmenname, String adresszeile1, String adresszeile2,
			int PLZ, String ort, String telefonnr, String emailadresse, int anzahlKonten) {
		Geschaeftskunde geschaeftskunde = new Geschaeftskunde(kundennr, firmenname, adresszeile1, adresszeile2, PLZ,
				ort, telefonnr, emailadresse, anzahlKonten);
		if (isVorhandenKdnr(kundennr) == false) {
			geschaeftskunde.makeKonten(anzahlKonten);
			this.addKunde(geschaeftskunde);
			ausgabe.printEingabenGespeichert();
		}
	}

	public void geschaeftskundeAnlegen(Geschaeftskunde geschaeftskunde) {
		if (isVorhandenKdnr(geschaeftskunde.getKundennr()) == false) {
			geschaeftskunde.makeKonten(geschaeftskunde.getMaxKonten());
			this.addKunde(geschaeftskunde);
			ausgabe.printEingabenGespeichert();
		}
	}

	/**
	 * CASE 3: KONTO ANLEGEN UND KUNDENNR ZUORDNEN. 
	 * Legt ein Konto fuer einen Privat- und/oder Geschaeftskunden an.
	 * 
	 * @param IBAN
	 *            IBAN des Kontos
	 * @param kontostand
	 *            Kontostand des Kontos
	 * @param kundennr
	 *            Kundennr die dem Konto zugeordnet werden soll
	 */
	public void kontoAnlegen(String IBAN, double kontostand, int kundennr) {
		boolean keinkunde = true;
		boolean nichtvorhanden = true;
		Konto konto = new Konto(IBAN, kontostand, kundennr);

		try {
			for (int i = 0; i < kundenarray.size(); i++) {
				if (kundenarray.get(i).getKundennr() == kundennr) {
					keinkunde = false;
					ArrayList<Konto> konten = kundenarray.get(i).getKonten();
					for (int j = 0; j < konten.size(); j++) {
						if (konten.get(j).getIBAN().equals(IBAN)) {
							nichtvorhanden = false;
							throw new Exception();
						}
					}
					break;
				}
			}
			if (keinkunde == true) {
				throw new Exception();
			}
		} catch (Exception e) {
			ausgabe.falscheEingabe();
		}
		for (int i = 0; i < kundenarray.size(); i++) {
			if (kundenarray.get(i).getKundennr() == kundennr && nichtvorhanden == true) {
				if (kundenarray.get(i).getKonten().size() >= kundenarray.get(i).getMaxKonten()) {
					ausgabe.printMaxKontenErreicht();
					throw new IndexOutOfBoundsException();
				} else {
					kundenarray.get(i).addKonto(konto);
					ausgabe.printEingabenGespeichert();
					break;
				}

			}
		}
	}

	/**
	 * CASE 4: KUNDE MIT KONTEN ANZEIGEN (AUSWAHL DURCH KUNDENNUMMER).
	 * Kundeninformationen und Konto/Konten anzeigen mithilfe der Kundennr.
	 * 
	 * @param kundennr
	 *            Kundennr des Privat- und/oder Geschaeftskunden
	 */
	public void kundeMitKontoAnzeigenKdnr(int kundennr) {
		try {
			boolean nichtvorhanden = true;
			for (int i = 0; i < kundenarray.size(); i++) {
				if (kundenarray.get(i).getKundennr() == kundennr) {
					nichtvorhanden = false;
					System.out.println(kundenarray.get(i).toString());
					ArrayList<Konto> konten = kundenarray.get(i).getKonten();
					for (int j = 0; j < konten.size(); j++) {
						System.out.println(konten.get(j).toString() + "\n");
					}
					break;
				}
			}
			if (nichtvorhanden == true) {
				throw new Exception();
			}
		} catch (Exception e) {
			ausgabe.printKdnrNichtVorhanden(kundennr);
		}
	}

	/**
	 * CASE 5: KUNDE MIT KONTEN ANZEIGEN (AUSWAHL DURCH NAME) 
	 * Kundeninformationen und Konto/Konten anzeigen mithilfe des Name.
	 * 
	 * @param name
	 *            Vor- und Nachname des Privatkunden; Firmenname des
	 *            Geschaeftskunden
	 */
	public void kundeMitKontoAnzeigenName(String name) {
		try {
			boolean nichtvorhanden = true;
			for (int i = 0; i < kundenarray.size(); i++) {
				if (kundenarray.get(i).getName().equals(name)) {
					nichtvorhanden = false;
					System.out.println(kundenarray.get(i).toString() + "\n");
					ArrayList<Konto> konten = kundenarray.get(i).getKonten();
					for (int j = 0; j < konten.size(); j++) {
						System.out.println(konten.get(j).toString() + "\n");
					}
					break;
				}
			}
			if (nichtvorhanden == true) {
				throw new Exception();
			}
		} catch (Exception e) {
			ausgabe.printNameNichtVorhanden(name);
		}
	}

	/**
	 * CASE 6: KONTO ANZEIGEN (AUSWAHL DURCH IBAN). 
	 * Konto/Konten anzeigen mithilfe der IBAN.
	 * 
	 * @param IBAN
	 */
	public void kontoAnzeigenIBAN(String IBAN) {
		HashMap<String, Konto> map = this.generateMap();
		if (map.containsKey(IBAN)) {
			System.out.println(map.get(IBAN) + "\n");
		}else {
			ausgabe.printIBANNotFound(IBAN);
		}
	}

	/**
	 * CASE 7: ALLE KUNDEN SORTIERT NACH AUFSTEIGENDER KUNDENNUMMER ANZEIGEN. 
	 * Alle Kunden sortiert nach aufsteigender Kundenummer.
	 */
	public void allKundenSortedKdnr() {
		Collections.sort(kundenarray, new Comparator<Kunde>() {
			@Override
			public int compare(Kunde k1, Kunde k2) {
				return k1.getKundennr()-(k2.getKundennr());
			}
		});
		for (Kunde kunde : kundenarray) {
			System.out.println(kunde.toString());
		}
	}

	/**
	 * CASE 8: ALLE KUNDEN SORTIERT NACH AUFSTEIGENDEM NAMEN UND NACHRANGIG NACH
	 * AUFSTEIGENDEM VORNAMEN ANZEIGEN. 
	 * Alle Kunden sortiert nach aufsteigendem Nachnamen und nachrangig nach aufsteigendem Vornamen.
	 */
	public void allKundenSortedName() {
		Collections.sort(kundenarray, new Comparator<Kunde>() {
			@Override
			public int compare(Kunde o1, Kunde o2) {
				return o1.getName().compareTo(o2.getName());
			}
		});
		for (Kunde kunde : kundenarray) {
			System.out.println(kunde.toString());
		}
	}

	/**
	 * CASE 9: ALLE KONTEN UNSORTIERT ANZEIGEN. 
	 * Alle Konten unsortiert.
	 */
	public void allKontoAnzeigen() {
		HashMap<String, Konto> map = this.generateMap();
		for (String iban : map.keySet()) {
			System.out.println(map.get(iban));
		}
	}

	/**
	 * CASE 10: BANKDATEN SPEICHERN. 
	 * Speichert die aktuellen Bankdaten.
	 */
	public void saveBankdaten() {
		FileOutputStream fileoutputstream = null;
		ObjectOutputStream objectoutputstream = null;
		ausgabe.printDateipfadEingeben();
		String dateiname = sc.nextLine();
		try {
			fileoutputstream = new FileOutputStream(dateiname);
			objectoutputstream = new ObjectOutputStream(fileoutputstream);
			objectoutputstream.writeObject(kundenarray);
			objectoutputstream.close();
			ausgabe.printErfolgGespeichert();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("\n");
		}
	}

	/**
	 * CASE 11: BANKDATEN LADEN. 
	 * Lädt die Daten aus einem spezifischen Dateipfad.
	 * 
	 * @param dateiname
	 *            Benutzer kann einen Dateinamen für die Datei festlegen
	 * 
	 */
	@SuppressWarnings("unchecked")
	public void loadBankdaten(String dateiname) {
		File datei = new File(dateiname);
		if (!datei.exists() || !datei.canRead()) {
			ausgabe.printDateiNotFound();
		}
		FileInputStream fileInputStream = null;
		ObjectInputStream objectInputStream = null;
		try {
			fileInputStream = new FileInputStream(dateiname);
			objectInputStream = new ObjectInputStream(fileInputStream);
			kundenarray = (ArrayList<Kunde>) objectInputStream.readObject();
		} catch (IOException | ClassNotFoundException e) {
			ausgabe.printFehlerDatenSchreiben();
			e.printStackTrace();
			System.out.println("\n");

			if (objectInputStream != null) {
				try {
					objectInputStream.close();
				} catch (IOException e1) {
					ausgabe.printFehlerCloseStream();
					e1.printStackTrace();
					System.out.println("\n");
				}
			}
		}
	}

	/**
	 * CASE 12: KUNDEN NACH NAMEN SORTIERT ALS CSV-DATEI EXPORTIEREN
	 * Export der Kunden sortiert nach Namen als CSV-Datei. 
	 */
	public void exportKunden() {
		try {
			PrintWriter writer = new PrintWriter("exportKunden.csv", "UTF-8");
			writer.write("Kundennr;Kundenname;Kundentyp;Kontostand\n");

			Collections.sort(kundenarray, new Comparator<Kunde>() {
				@Override
				public int compare(Kunde o1, Kunde o2) {
					return o1.getName().compareTo(o2.getName());
				}
			});

			for (int i = 0; i < kundenarray.size(); i++) {
				writer.write(kundenarray.get(i).getKundennr() + ";" + kundenarray.get(i).getName() + ";"
						+ getKundentyp(kundenarray.get(i)) + ";" + getTotalKontostand(kundenarray.get(i)) + " Euro\n");
			}
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println("\n");
		}
	}
	
	/**
	 * CASE 13: GELD EINZAHLEN
	 */
	public void geldEinzahlung(String IBAN, double geldbetrag) {
		HashMap<String, Konto> map = this.generateMap();
		if (map.containsKey(IBAN)) {
			Konto currentkonto = map.get(IBAN);
			currentkonto.setLetzteEinAusZahlung(geldbetrag);
			currentkonto.setKontostand(currentkonto.getKontostand() + currentkonto.getLetzteEinAusZahlung());
			Logger log = Logger.getInstance();
			if(auswahl == 1) {
				log.consoleAusgabe("Auf das Konto: " + IBAN + " wurde(n) " + currentkonto.getLetzteEinAusZahlung() + "€ EINGEZAHLT. Aktueller Kontostand: " + currentkonto.getKontostand());
			}else if(auswahl == 2) {
				log.export("Auf das Konto: " + IBAN + " wurde(n) " + currentkonto.getLetzteEinAusZahlung() + "€ EINGEZAHLT. Aktueller Kontostand: " + currentkonto.getKontostand());
			}
			ausgabe.printEinzahlungSucc();
			setChanged();
			if(currentkonto.getLetzteEinAusZahlung() < 10000) {
				for (Bankangestellter bankangestellter : bankangestelltearray) {
					bankangestellter.update(this, currentkonto);
				}
			}else if(currentkonto.getLetzteEinAusZahlung() >= 10000) {
				notifyObservers(currentkonto);
			}
		}else {
			ausgabe.printIBANNotFound(IBAN);
		}
	}
	
	/**
	 * CASE 14: GELD AUSZAHLEN
	 */
	public void geldAuszahlung(String IBAN, double geldbetrag) {
		HashMap<String, Konto> map = this.generateMap();
		if (map.containsKey(IBAN)) {
			Konto currentkonto = map.get(IBAN);
			currentkonto.setLetzteEinAusZahlung(geldbetrag);
			currentkonto.setKontostand(currentkonto.getKontostand() - currentkonto.getLetzteEinAusZahlung());
			Logger log = Logger.getInstance();
			if(auswahl == 1) {
				log.consoleAusgabe("Von dem Konto: " + IBAN + " wurde(n) " + currentkonto.getLetzteEinAusZahlung() + "€ AUSGEZAHLT. Aktueller Kontostand: " + currentkonto.getKontostand());
			}else if(auswahl == 2) {
				log.export("Von dem Konto: " + IBAN + " wurde(n) " + currentkonto.getLetzteEinAusZahlung() + "€ AUSGEZAHLT. Aktueller Kontostand: " + currentkonto.getKontostand());
			}
			ausgabe.printAuszahlungSucc();
			setChanged();
			if(currentkonto.getLetzteEinAusZahlung() < 10000) {
				for (Bankangestellter bankangestellter : bankangestelltearray) {
					bankangestellter.update(this, currentkonto);
				}
			}else if(currentkonto.getLetzteEinAusZahlung() >= 10000) {
				notifyObservers(currentkonto);
			}
		}else {
			ausgabe.printIBANNotFound(IBAN);
		}
	}
	
	/**
	 * CASE 15: LOG-STRATEGIE WÄHLEN
	 * (1) Konsolenausgabe
	 * (2) Export als txt-Datei
	 */
	public void logStrategieWaehlen() {	
		do {
			ausgabe.printLogStrategieWaehlen();
			try {
				mode = sc.nextInt();
				switch(mode) {
					case 1: 
						auswahl = 1;
						ausgabe.printLogStrategie1();
						break;
						
					case 2:
						auswahl = 2;
						ausgabe.printLogStrategie2();
						break;
						
					default:
						ausgabe.falscheEingabe();
						break;
				}
			}catch(Exception e) {
				falscheEingabe = true;
				ausgabe.printRichtigeAngaben();
			}
		}while(falscheEingabe == true);
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getBLZ() {
		return BLZ;
	}

	public void setBLZ(int bLZ) {
		BLZ = bLZ;
	}

	public String getBIC() {
		return BIC;
	}

	public void setBIC(String bIC) {
		BIC = bIC;
	}

	public ArrayList<Kunde> getKundenarray() {
		return kundenarray;
	}

	public void setKundenarray(ArrayList<Kunde> kundenarray) {
		this.kundenarray = kundenarray;
	}
	
	public Kunde getKundenByName(String name) {
		for(Kunde kunde : kundenarray) {
			if(kunde.getName().equals(name)) {
				return kunde;
			}
		}
		return null;
	}
	
	public double getTotalKontostandAllKonten() {
		double gesamtKontostand = 0.0;
		for(Kunde kunde : this.kundenarray) {
			for(Konto konto : kunde.getKonten()) {
				gesamtKontostand = gesamtKontostand + konto.getKontostand();
			}
		}
		return gesamtKontostand;
	}
	
	public double getKontostandstandIBAN(String IBAN) {
		double kontostand = 0.0;
		for (Kunde kunde : this.kundenarray) {
			for (Konto konto : kunde.getKonten()) {
				if(IBAN.equals(konto.getIBAN())) {
					kontostand = konto.getKontostand();
				}
			}
		}
		return kontostand;
	}
}