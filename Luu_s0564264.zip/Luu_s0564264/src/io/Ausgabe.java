package io;

import java.io.File;
import java.io.Serializable;

import bank.Bank;

/**
 * Output-Klasse. 
 * 
 * @author s0564264 Carmen Luu (s0564264@htw-berlin.de)
 *
 */

public class Ausgabe implements Serializable {
	public void printMenu() {
		System.out.println("(1) Privatkunde anlegen\n" + "(2) Geschäftskunde anlegen\n"
				+ "(3) Konto anlegen und Kundennr zuordnen\n" 
				+ "______________________________________________________________________________________________________________________________\n"
				+ "(4) Kunde mit Konten anzeigen (Auswahl durch Kundennummer)\n" 
				+ "(5) Kunde mit Konten anzeigen (Auswahl durch Name)\n" + "(6) Konto anzeigen (Auswahl durch IBAN)\n"
				+ "______________________________________________________________________________________________________________________________\n"
				+ "(7) Alle Kunden sortiert nach aufsteigender Kundennummer anzeigen\n" 
				+ "(8) Alle Kunden sortiert nach aufsteigendem Nachnamen und nachrangig nach aufsteigendem Vornamen anzeigen\n"
				+ "(9) Alle Konten unsortiert anzeigen\n"
				+ "______________________________________________________________________________________________________________________________\n"
				+ "(10) Bankdaten speichern\n"
				+ "(11) Bankdaten laden\n"
				+ "(12) Kunden nach Namen sortiert als CSV-Datei exportieren\n"
				+ "______________________________________________________________________________________________________________________________\n"
				+ "(13) Geld einzahlen\n"
				+ "(14) Geld auszahlen\n"
				+ "(15) Log-Strategie wählen\n"
				+ "______________________________________________________________________________________________________________________________\n"
				+ "(16) GUI für Ein- und Auszahlungen öffnen\n"
				+ "______________________________________________________________________________________________________________________________\n"
				+ "(17) Monitoring aktivieren\n"
				+ "(18) Monitoring deaktivieren\n"
				+ "______________________________________________________________________________________________________________________________\n"
				+ "(19) Beenden");
	}
	
	public void printAnlegen() {
		System.out.println("\nBitte geben Sie folgendes an:");
	}
	
	public void printAnlegenKdnr() {
		System.out.println("\nKundennr:");
	}
	
	public void printPKAnlegenAnrede() {
		System.out.println("\nAnrede:");
	}
	
	public void printPKAnlegenVorn() {
		System.out.println("\nVorname:");
	}
	
	public void printPKAnlegenNachn() {
		System.out.println("\nNachname:");
	}
	
	public void printPKAnlegenGeb() {
		System.out.println("\nGeburtsdatum:");
	}
	
	public void printAnlegenAdr1() {
		System.out.println("\nAdresszeile1:");
	}
	
	public void printAnlegenAdr2() {
		System.out.println("\nAdresszeile2:");
	}
	
	public void printAnlegenPLZ() {
		System.out.println("\nPLZ:");
	}
	
	public void printAnlegenOrt() {
		System.out.println("\nOrt:");
	}
	
	public void printAnlegenTele() {
		System.out.println("\nTelefonnr:");
	}
	
	public void printAnlegenEmail() {
		System.out.println("\nE-Mail-Adresse:");
	}
	
	public void printAnlegenAnzKonten() {
		System.out.println("\nAnzahl der Konten:");
	}
	
	public void printGKFirmenname() {
		System.out.println("\nFirmenname:");
	}
	
	public void printAnlegenIBAN() {
		System.out.println("IBAN:");
	}
	
	public void printAnlegenKontostand() {
		System.out.println("\nKontostand:");
	}
	
	public void printkundeMitKontoAnzeigenKdnr() {
		System.out.println("Bitte geben Sie folgendes an: Kundennr");
	}
	
	public void printKundeMitKontoAnzeigenName() {
		System.out.println("Bitte geben Sie folgendes an: Nachname & Vorname ODER Firmenname.");
	}
	
	public void printKontoAnzeigenIBAN() {
		System.out.println("Bitte geben Sie folgendes an: IBAN.");
	}
	
	public void printProgrammBeenden() {
		System.out.println("PROGRAMM BEENDET.");
	}
	
	public void printGueltigeZahlEingeben() {
		System.out.println("Bitte gueltige Zahl eingeben!\n");
	}
	
	public void printRichtigeAngaben() {
		System.out.println("Bitte richtige Angaben!\n");
	}
	
	public void printZuVieleKonten() {
		System.out.println("Zu viele Konten. Maximale Eingabe 10!\n");
	}
	
	public void printEingabenGespeichert() {
		System.out.println("Eingaben erfolgreich gespeichert!\n");
	}
	
	public void printKdnrExistiertBereits() {
		System.out.println("Diese Kundennr existiert bereits.\n");
	}
	
	public void printMaxKontenErreicht() {
		System.out.println("Maximale Anzahl an Konten bereits erreicht.\n");
	}
	
	public void printKdnrNichtVorhanden(int kundennr) {
		System.out.println("Kundennummer: '" + kundennr + "' ist nicht vorhanden.\n");
	}
	
	public void printNameNichtVorhanden(String name) {
		System.out.println("Name: '" + name + "' ist nicht vorhanden.\n");
	}
	
	public void printIBANNichtVorhanden() {
		System.out.println("IBAN nicht vorhanden.");
	}
	
	public void printPrivkundeAnl() {
		System.out.println("PRIVATKUNDE ANLEGEN:");
	}
	
	public void printGeschaeftskundeAnl(){
		System.out.println("GESCHÄFTSKUNDE ANLEGEN:");
	}
	
	public void printKontoAnlegenKdnr() {
		System.out.println("KONTO ANLEGEN UND KUNDENNR ZUORDNEN:");
	}
	
	public void printKundeKontenAnzKdnr() {
		System.out.println("KUNDE MIT KONTEN ANZEIGEN (AUSWAHL DURCH KUNDENNUMMER):\n");
	}
	
	public void printKundeKontenAnzName() {
		System.out.println("KUNDE MIT KONTEN ANZEIGEN (AUSWAHL DURCH NAME):\n");
	}
	
	public void printKontoAnzIBAN() {
		System.out.println("KONTO ANZEIGEN (AUSWAHL DURCH IBAN):\n");
	}
	
	public void printAlleKundenAufsteigKdnr() {
		System.out.println("ALLE KUNDEN SORTIERT NACH AUFSTEIGENDER KUNDENNUMMER ANZEIGEN:\n");
	}
	
	public void printAlleKundenAufsteigNachnVorn() {
		System.out.println("ALLE KUNDEN SORTIERT NACH AUFSTEIGENDEM NACHNAMEN UND NACHRANGIG NACH AUFSTEIGENDEM VORNAMEN ANZEIGEN:\n");
	}
	
	public void printAlleKontenUnsortAnzeigen() {
		System.out.println("ALLE KONTEN UNSORTIERT ANZEIGEN:\n");
	}
	
	public void printGeldEinzahlen() {
		System.out.println("GELD EINZAHLEN:\n");
	}
	
	public void printGeldAuszahlen() {
		System.out.println("GELD AUSZAHLEN:\n");
	}
	
	public void printLogStrategie() {
		System.out.println("LOG-STRATEGIE WÄHLEN:\n");
	}
	
	public void falscheEingabe() {
		System.out.println("Bitte richtige Angaben!");
	}
	
	public void falscheKontenAnzahl() {
		System.out.println("Anzahl der Konten stimmt nicht mit Anzahl der maximalen Konten ueberein.");
	}
	
	public void falscheAnrede() {
		System.out.println("Anrede falsch!");
	}
	
	public void printBankdatenSave() {
		System.out.println("BANKDATEN SPEICHERN:\n");
	}
	
	public void printLoadBankdaten() {
		System.out.println("BANKDATEN LADEN:\n");
	}
	
	public void printBankdatenExport() {
		System.out.println("KUNDEN NACH NAMEN SORTIERT ALS CSV-DATEI EXPORTIEREN:\n");
	}
	
	public void printGUI() {
		System.out.println("GUI FÜR EIN- UND AUSZAHLUNGEN ÖFFNEN:");
	}
	
	public void printMonitoringAkt() {
		System.out.println("MONITORING AKTIVIEREN:\n");
	}
	
	public void printMonitoringDeakt() {
		System.out.println("MONITORING DEAKTIVIEREN:\n");
	}
	
	public void printAlleKundenSortCSVexp(Bank bank) {
		System.out.println(bank.getKundenarray().size() + " Datensätze in die Datei " + System.getProperty("user.dir") + File.separator + "exportKunden.csv exportiert.");
	}
	
	public void printDateipfadEingeben() {
		System.out.println("Bitte geben Sie einen Dateipfad ein.");
	}
	
	public void printErfolgGespeichert() {
		System.out.println("Erfolgreich gespeichert!\n");
	}
	
	public void printDateiNotFound() {
		System.out.println("Die Datei existiert nicht oder kann nicht gelesen werden.");
	}
	
	public void printFehlerDatenSchreiben() {
		System.out.println("Es ist ein Fehler beim Schreiben der Daten aufgetreten.");
	}
	
	public void printFehlerCloseStream() {
		System.out.println("Es ist ein Fehler beim Schließen des Streams aufgetreten.");
	}
	
	public void printIBANNotFound(String IBAN) {
		System.out.println("IBAN: '" + IBAN + "' nicht vorhanden.\n");
	}
	
	public void printEinzahlungGeldbetrag() {
		System.out.println("\nBitte geben sie den gewünschten einzuzahlenden Geldbetrag ein.\n");
	}
	
	public void printAuszahlungGeldbetrag() {
		System.out.println("\nBitte geben sie den gewünschten auszuzahlenden Geldbetrag ein.\n");
	}
	
	public void printEinzahlungSucc() {
		System.out.println("Einzahlung erfolgreich.\n");
	}
	
	public void printAuszahlungSucc() {
		System.out.println("Auszahlung erfolgreich.\n");
	}
	
	public void printLogStrategieWaehlen() {
		System.out.println("(1) Konsolenausgabe\n" + "(2) Export txt-Datei\n");
	}
	
	public void printLogStrategie1() {
		System.out.println("Log-Strategie: Konsolenausgabe gewählt.\n");
	}
	
	public void printLogStrategie2() {
		System.out.println("Log-Strategie: txt-Datei gewählt.\n");
	}
	
	public void printMonitoringAktiviert() {
		System.out.println("Monitoring wurde erfolgreich AKTIVIERT.\n");
	}
	
	public void printMonitoringDeaktiviert() {
		System.out.println("Monitoring wurde erfolgreich DEAKTIVIERT.\n");
	}
	
	public void printKeinMonitorerVorhanden() {
		System.out.println("Es ist momentan kein Monitorer aktiviert.\n");
	}
	
}
