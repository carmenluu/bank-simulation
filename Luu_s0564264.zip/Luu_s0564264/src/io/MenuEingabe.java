package io;

import java.io.Serializable;
import java.util.Scanner;
import adresse.Adresse;
import bank.Bank;
import kunde.Geschaeftskunde;
import kunde.Privatkunde;
import monitoring.Monitorer;
import view.MyFrame;
import bankmitarbeiter.*;

/**
 * Menu mit 19 Auswahlmoeglichkeiten.
 * 
 * @author s0564264 Carmen Luu (s0564264@htw-berlin.de)
 *
 */

public class MenuEingabe implements Serializable {
	private boolean falscheEingabe = false;
	Monitorer monitorer = null;
	Scanner scan;
	Ausgabe ausgabe = new Ausgabe();

	/**
	 * Menu mit 17 Auswahlmoeglichkeiten. 
	 * case 1: Anlegen eines Privatkunden. 
	 * case 2: Anlegen eines Geschaefskunden. 
	 * case 3: Anlegen eines Konto fuer Privat- und/oder Geschaeftskunden. 
	 * case 4: Kundeninformationen mit Konto/Konten anzeigen mithilfe der Kundennr. 
	 * case 5: Kundeninformationen mit Konto/Konten anzeigen mithilfe des Namen. 
	 * case 6: Konto/Konten anzeigen mithilfe der IBAN. 
	 * case 7: Alle Kunden sortiert nach aufsteigender Kundenummer anzeigen. 
	 * case 8: Alle Kunden sortiert nach aufsteigendem Nachnamen und nachrangig nach aufsteigendem Vornamen anzeigen. 
	 * case 9: Alle Konten unsortiert anzeigen. 
	 * case 10: Bankdaten speichern.
	 * case 11: Bankdaten laden.
	 * case 12: Kunden nach Namen sortiert als CSV-Datei exportieren.
	 * case 13: Geld einzahlen.
	 * case 14: Geld auszahlen.
	 * case 15: Log-Strategie wählen.
	 * case 16: GUI für Ein- und Auszahlungen öffnen.
	 * case 17: Monitoring aktivieren.
	 * case 18: Monitoring deaktiveren.
	 * case 19: Beenden des Programms.
	 * 
	 * @param bank
	 */
	public void start(Bank bank) {
		bank.vorstandAnlegen("Grunow", "Karl");
		bank.bankangestellenAnlegen("Grey", "Jonas");
		
		bank.privatKundeAnlegen(11, "frau", "Leona", "Til", "01.06.1987", "Lipschitzallee", "12", 12345,
				"Berlin", "306064768", "leona.til@privatkunde.de", 3);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 57", 10000, 11);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 58", 2000, 11);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 59", 300, 11);
		
		bank.privatKundeAnlegen(12, "herr", "Leo", "Vancouv", "11.04.1996", "Lipschitzallee", "13", 12345,
				"Berlin", "306064769", "leo.vancouv@privatkunde.de", 2);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 60", 20000, 12);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 61", 3000, 12);
		
		bank.privatKundeAnlegen(13, "frau", "Michelle", "Knaut", "26.09.1968", "Lipschitzallee", "14",
				12345, "Berlin", "306064770", "michelle.knaut@privatkunde.de", 1);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 62", 30000, 13);
		
		bank.privatKundeAnlegen(14, "herr", "Thomas", "Caspary", "04.11.1991", "Lipschitzallee", "15",
				12345, "Berlin", "306064771", "thomas.caspary@privatkunde.de", 1);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 63", 300, 14);
		
		bank.privatKundeAnlegen(15, "frau", "Ina", "Nussbaum", "11.08.1996", "Lipschitzallee", "16", 12345,
				"Berlin", "306064772", "ina.nussbaum@privatkunde.de", 3);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 64", 40000, 15);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 65", 5000, 15);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 66", 600, 15);
		
		bank.geschaeftskundeAnlegen(16, "Firmenname1", "Lipschitzallee", "17", 12345, "Berlin", "306064773",
				"firmenname1@geschaeftskunde.de", 2);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 67", 50000, 16);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 68", 6000, 16);
		
		bank.geschaeftskundeAnlegen(17, "Firmenname2", "Lipschitzallee", "18", 12345, "Berlin", "306064774",
				"firmenname2@geschaeftskunde.de", 1);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 69", 60000, 17);
		
		bank.geschaeftskundeAnlegen(18, "Firmenname3", "Lipschitzallee", "19", 12345, "Berlin", "306064775",
				"firmenname3@geschaeftskunde.de", 1);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 70", 30000, 18);
		
		bank.geschaeftskundeAnlegen(19, "Firmenname4", "Lipschitzallee", "20", 12345, "Berlin", "306064776",
				"firmenname4@geschaeftskunde.de", 3);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 71", 70000, 19);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 72", 8000, 19);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 73", 900, 19);
		
		bank.geschaeftskundeAnlegen(20, "Firmenname5", "Lipschitzallee", "21", 12345, "Berlin", "306064777",
				"firmenname5@geschaeftskunde.de", 2);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 74", 100000, 20);
		bank.kontoAnlegen("DE87 1005 0000 1076 1077 75", 9000, 20);
		
		do {
			ausgabe.printMenu();
			falscheEingabe = true;
			try {
				scan = new Scanner(System.in);
				int mode = scan.nextInt();
				switch (mode) {	
				case 1:
					ausgabe.printPrivkundeAnl();
					Privatkunde privatkunde = new Privatkunde(0, "", "", "", "", "", "", 0, "", "", "", 0);
					Scanner scanner;
					int kundennr = 0;
					String anredePK = "";
					String vornamePK = "";
					String nachnamePK = "";
					String geburtsdatumPK = "";
					String adresszeile1 = "";
					String adresszeile2 = "";
					int PLZ = 0;
					String ort = "";
					String telefonnr = "";
					String emailadresse = "";
					int anzahlKonten = 0;
					ausgabe.printAnlegen();

					Object[] objects = new Object[12];
					for (int i = 0; i < objects.length; i++) {
						try {
							if (i == 0) {
								i = i - 1;
								ausgabe.printAnlegenKdnr();
								scanner = new Scanner(System.in);
								kundennr = scanner.nextInt();
								privatkunde.setKundennr(kundennr);
								if (privatkunde.getKundennr() == kundennr && bank.isVorhandenKdnr(kundennr) == false) {
									i++;
								}
							}
							if (i == 1) {
								i = i - 1;
								ausgabe.printPKAnlegenAnrede();
								scanner = new Scanner(System.in);
								anredePK = scanner.next();
								privatkunde.setAnrede(anredePK);
								if (privatkunde.getAnrede().toString().equals(anredePK.toUpperCase())) {
									i++;
								}
							}
							if (i == 2) {
								ausgabe.printPKAnlegenVorn();
								scanner = new Scanner(System.in);
								vornamePK = scanner.next();
								privatkunde.setVorname(vornamePK);
							}
							if (i == 3) {
								ausgabe.printPKAnlegenNachn();
								scanner = new Scanner(System.in);
								nachnamePK = scanner.next();
								privatkunde.setNachname(nachnamePK);
							}
							if (i == 4) {
								ausgabe.printPKAnlegenGeb();
								scanner = new Scanner(System.in);
								geburtsdatumPK = scanner.next();
								privatkunde.setGeburtsdatum(geburtsdatumPK);
							}
							if (i == 5) {
								ausgabe.printAnlegenAdr1();
								scanner = new Scanner(System.in);
								adresszeile1 = scanner.next();
							}
							if (i == 6) {
								ausgabe.printAnlegenAdr2();
								scanner = new Scanner(System.in);
								adresszeile2 = scanner.next();
							}
							if (i == 7) {
								i = i - 1;
								ausgabe.printAnlegenPLZ();
								scanner = new Scanner(System.in);
								PLZ = scanner.nextInt();
								if (privatkunde.getKundennr() == kundennr) {
									i++;
								}
							}
							if (i == 8) {
								ausgabe.printAnlegenOrt();
								scanner = new Scanner(System.in);
								ort = scanner.next();
								Adresse adresse = new Adresse(adresszeile1, adresszeile2, PLZ, ort);
								privatkunde.setAdresse(adresse);
							}
							if (i == 9) {
								ausgabe.printAnlegenTele();
								scanner = new Scanner(System.in);
								telefonnr = scanner.next();
								privatkunde.setTelefonnr(telefonnr);
							}
							if (i == 10) {
								ausgabe.printAnlegenEmail();
								scanner = new Scanner(System.in);
								emailadresse = scanner.next();
								privatkunde.setEmailadresse(emailadresse);
							}
							if (i == 11) {
								i = i - 1;
								ausgabe.printAnlegenAnzKonten();
								scanner = new Scanner(System.in);
								anzahlKonten = scanner.nextInt();
								privatkunde.setMaxkonten(anzahlKonten);
								
								bank.privatKundeAnlegen(privatkunde);
								if (privatkunde.getMaxKonten() == anzahlKonten) {
									i++;
								}
							}
						} catch (Exception e) {
							ausgabe.falscheEingabe();
						}
					}
					break;

				case 2:
					ausgabe.printGeschaeftskundeAnl();
					Geschaeftskunde geschaeftskunde = new Geschaeftskunde(0, "", "", "", 0, "", "", "", 0);
					kundennr = 0;
					String firmenname = "";
					adresszeile1 = "";
					adresszeile2 = "";
					PLZ = 0;
					ort = "";
					telefonnr = "";
					emailadresse = "";
					anzahlKonten = 0;
					ausgabe.printAnlegen();

					Object[] objects2 = new Object[9];
					for (int i = 0; i < objects2.length; i++) {
						try {
							if (i == 0) {
								i = -1;
								ausgabe.printAnlegenKdnr();
								scanner = new Scanner(System.in);
								kundennr = scanner.nextInt();
								geschaeftskunde.setKundennr(kundennr);
								if (geschaeftskunde.getKundennr() == kundennr && bank.isVorhandenKdnr(kundennr) == false) {
									i++;
								}
							}
							if (i == 1) {
								ausgabe.printGKFirmenname();
								scanner = new Scanner(System.in);
								firmenname = scanner.next();
								geschaeftskunde.setFirmenname(firmenname);
							}
							if (i == 2) {
								ausgabe.printAnlegenAdr1();
								scanner = new Scanner(System.in);
								adresszeile1 = scanner.next();
							}
							if (i == 3) {
								ausgabe.printAnlegenAdr2();
								scanner = new Scanner(System.in);
								adresszeile2 = scanner.next();
							}
							if (i == 4) {
								i = i - 1;
								ausgabe.printAnlegenPLZ();
								scanner = new Scanner(System.in);
								PLZ = scanner.nextInt();
								if (geschaeftskunde.getKundennr() == kundennr) {
									i++;
								}
							}
							if (i == 5) {
								ausgabe.printAnlegenOrt();
								scanner = new Scanner(System.in);
								ort = scanner.next();
								Adresse adresse = new Adresse(adresszeile1, adresszeile2, PLZ, ort);
								geschaeftskunde.setAdresse(adresse);
							}
							if (i == 6) {
								ausgabe.printAnlegenTele();
								scanner = new Scanner(System.in);
								telefonnr = scanner.next();
								geschaeftskunde.setTelefonnr(telefonnr);
							}
							if (i == 7) {
								ausgabe.printAnlegenEmail();
								scanner = new Scanner(System.in);
								emailadresse = scanner.next();
								geschaeftskunde.setEmailadresse(emailadresse);
							}
							if (i == 8) {
								i = i - 1;
								ausgabe.printAnlegenAnzKonten();
								scanner = new Scanner(System.in);
								anzahlKonten = scanner.nextInt();
								geschaeftskunde.setMaxkonten(anzahlKonten);
								
								bank.geschaeftskundeAnlegen(geschaeftskunde);
								if (geschaeftskunde.getMaxKonten() == anzahlKonten) {
									i++;
								}
							}
						} catch (Exception e) {
							ausgabe.falscheEingabe();
						}
					}
					break;

				case 3:
					ausgabe.printKontoAnlegenKdnr();
					ausgabe.printAnlegen();
					ausgabe.printAnlegenIBAN();
					String IBAN = scan.next();
					ausgabe.printAnlegenKontostand();
					double kontostand = scan.nextDouble();
					ausgabe.printAnlegenKdnr();
					kundennr = scan.nextInt();

					bank.kontoAnlegen(IBAN, kontostand, kundennr);
					break;

				case 4:
					ausgabe.printKundeKontenAnzKdnr();
					ausgabe.printkundeMitKontoAnzeigenKdnr();
					int kundennr4 = scan.nextInt();

					bank.kundeMitKontoAnzeigenKdnr(kundennr4);
					break;

				case 5:
					ausgabe.printKundeKontenAnzName();
					ausgabe.printKundeMitKontoAnzeigenName();
					Scanner namescanner = new Scanner(System.in);
					String name = namescanner.nextLine();
					
					bank.kundeMitKontoAnzeigenName(name);
					break;

				case 6:
					ausgabe.printKontoAnzIBAN();
					ausgabe.printKontoAnzeigenIBAN();
					Scanner ibanscanner = new Scanner(System.in);
                    String IBAN6 = ibanscanner.nextLine();

					bank.kontoAnzeigenIBAN(IBAN6);
					break;

				case 7:
					ausgabe.printAlleKundenAufsteigKdnr();
					
					bank.allKundenSortedKdnr();
					break;

				case 8:
					ausgabe.printAlleKundenAufsteigNachnVorn();
					
					bank.allKundenSortedName();
					break;

				case 9:
					ausgabe.printAlleKontenUnsortAnzeigen();
					
					bank.allKontoAnzeigen();
					break;

				case 10:
					ausgabe.printBankdatenSave();
					
					bank.saveBankdaten();
					break;
					
				case 11:
					ausgabe.printLoadBankdaten();
					ausgabe.printDateipfadEingeben();
					String datenPath = scan.next();
					System.out.println(datenPath + " wurde geladen.\n");
					
					bank.loadBankdaten(datenPath);
					break;
					
				case 12:
					ausgabe.printBankdatenExport();
					ausgabe.printAlleKundenSortCSVexp(bank);
					System.out.println();
					
					bank.exportKunden();
					break;
					
				case 13:
					ausgabe.printGeldEinzahlen();
					Scanner ibanscan13 = new Scanner(System.in);
					ausgabe.printKontoAnzeigenIBAN();
					String IBAN13 = ibanscan13.nextLine();
					ausgabe.printEinzahlungGeldbetrag();
					double geldbetrag13 = scan.nextDouble();
					
					bank.geldEinzahlung(IBAN13, geldbetrag13);
					break;
					
				case 14:
					ausgabe.printGeldAuszahlen();
					Scanner ibanscan14 = new Scanner(System.in);
					ausgabe.printKontoAnzeigenIBAN();
					String IBAN14 = ibanscan14.nextLine();
					ausgabe.printAuszahlungGeldbetrag();
					double geldbetrag14 = scan.nextDouble();
					
					bank.geldAuszahlung(IBAN14, geldbetrag14);
					break;
					
				case 15:
					ausgabe.printLogStrategie();
					
					bank.logStrategieWaehlen();
					break;
					
				case 16: 
					ausgabe.printGUI();
					
					MyFrame myframe = new MyFrame(bank);
					myframe.setVisible(true);
					break;
					
				case 17:
					monitorer = new Monitorer(bank);
					Thread threadAkt = new Thread(monitorer);
					threadAkt.start();
					ausgabe.printMonitoringAktiviert();
					
					break;
					
				case 18:
					if(monitorer == null) {
						ausgabe.printKeinMonitorerVorhanden();
					}else {
						ausgabe.printMonitoringDeaktiviert();
						monitorer.stop();
					}
					
					break;
					
				case 19:
					if(monitorer == null) {
						ausgabe.printProgrammBeenden();
						System.exit(0);
					}else {
						ausgabe.printProgrammBeenden();
						monitorer.stop();
						System.exit(0);
					}
					
				default:
					ausgabe.printGueltigeZahlEingeben();
					break;
				}
			} catch (Exception e) {
				falscheEingabe = true;
				ausgabe.printRichtigeAngaben();
				continue;
			}
		} while (falscheEingabe == true);
	}
}
