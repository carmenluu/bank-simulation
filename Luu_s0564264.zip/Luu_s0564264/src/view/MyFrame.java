package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

import bank.Bank;
import bank.Konto;
import kunde.Kunde;

/**
 * GUI für Ein- und Auszahlungen.
 * 
 * @author s0564264 Carmen Luu (s0564264@htw-berlin.de)
 *
 */

public class MyFrame extends JFrame implements ActionListener {
	public Bank bank;
	private ArrayList<Konto> konten = new ArrayList();
	private JButton info;
	private JMenuBar menubar;
	private JComboBox box;
	private JButton auswahl;
	private JLabel iban1;
	private JLabel iban2;
	private JLabel iban3;
	private JLabel kontoStand;
	private JLabel kontoStandText1;
	private JLabel kontoStandText2;
	private JLabel kontoStandText3;
	private JPanel panel1;
	private JPanel panel2;
	private JPanel panel3;
	private JTextField zahlung1;
	private JTextField zahlung2;
	private JTextField zahlung3;
	private JButton einzahlen1;
	private JButton einzahlen2;
	private JButton einzahlen3;
	private JButton auszahlen1;
	private JButton auszahlen2;
	private JButton auszahlen3;
	private Konto konto1;
	private Konto konto2;
	private Konto konto3;
	JTextArea textArea = new JTextArea();

	/**
	 * Erstellt das GUI.
	 * 
	 * @param bank
	 */
	public MyFrame(Bank bank) {
		this.setBank(bank);
		this.prepareFrame();
	}

	/**
	 * MenuBar für das GUI.
	 * 
	 * @return menubar
	 */
	public JMenuBar setUpMenuBar() {
		menubar = new JMenuBar();
		info = new JButton("Info");
		info.setFont(new Font("Tahoma", Font.PLAIN, 14));
		box = new JComboBox();
		auswahl = new JButton("Kunde wählen");
		auswahl.setFont(new Font("Tahoma", Font.PLAIN, 14));

		for (Kunde kunde : bank.getKundenarray()) {
			box.addItem(kunde.getName());
			box.setFont(new Font("Tahoma", Font.PLAIN, 14));
		}

		auswahl.addActionListener(this);
		info.addActionListener(this);
		menubar.add(box);
		menubar.add(auswahl);
		menubar.add(info);
		return menubar;
	}

	/**
	 * Einstellungen für das GUI-Fenster.
	 */
	private void prepareFrame() {
		int width = 1000;
		int height = 1000;

		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

		this.setLocation((int) (screenSize.getWidth() - width) / 2, (int) (screenSize.getHeight() - height) / 2);
		this.setUpMenuBar();
		this.setJMenuBar(menubar);
		this.setLayout(new GridBagLayout());
		this.setPreferredSize(new Dimension(width, height));
		this.setTitle("Konten");
		this.setMaximumSize(new Dimension(width, height));
		this.setCenterFrame();
		this.setBottomFrame();
		this.pack();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setExtendedState(JFrame.MAXIMIZED_BOTH);
		this.setVisible(true);
	}

	/**
	 * Oberer Bereich des GUI-Fensters.
	 */
	public void setCenterFrame() {
		GridBagConstraints gbc = new GridBagConstraints();
		JPanel center = new JPanel();
		center.setPreferredSize(new Dimension(1900, 2000));
		center.setMaximumSize(Toolkit.getDefaultToolkit().getScreenSize());
		center.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.BLACK, Color.BLACK));

		textArea.setFont(new Font("Tahoma", Font.PLAIN, 14));
		textArea.setText("Bitte wählen Sie einen Kunden aus um fortzufahren.");
		textArea.setPreferredSize(new Dimension(1900, 2000));
		textArea.setMaximumSize(new Dimension(1900, 2000));
		textArea.setWrapStyleWord(true);

		JScrollPane scrollpane = new JScrollPane(textArea);
		scrollpane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		scrollpane.setPreferredSize(new Dimension(1900, 2000));
		scrollpane.setMaximumSize(new Dimension(1900, 2000));

		setConstraints(gbc, 0, true, 0);
		center.add(scrollpane, gbc);

		gbc.gridwidth = 3;
		this.getContentPane().add(center, gbc);
		gbc.gridwidth = 1;
	}

	public void setConstraints(GridBagConstraints gbc, int x, int y, boolean fill) {
		gbc.gridx = x;
		gbc.gridy = y;
		gbc.weightx = 0.1;
		gbc.weighty = 0.1;
		gbc.fill = fill ? GridBagConstraints.HORIZONTAL : GridBagConstraints.NONE;
	}

	public void setConstraints(GridBagConstraints gbc, int x, boolean fillBoth, int y) {
		gbc.gridx = x;
		gbc.gridy = y;
		gbc.weightx = 0.1;
		gbc.weighty = 0.1;
		gbc.fill = GridBagConstraints.BOTH;
	}

	/**
	 * Unterer Bereich des GUI-Fensters.
	 */
	public void setBottomFrame() {
		GridBagConstraints gbc = new GridBagConstraints();

		panel1 = new JPanel();
		panel1.setLayout(new GridBagLayout());
		panel1.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.BLACK, Color.BLACK));
		panel1.setPreferredSize(new Dimension(1000, 500));

		iban1 = getIbanLabel("LEER", gbc, 0);

		panel1.add(iban1, gbc);

		gbc.gridwidth = 1;

		kontoStand = getKontostandLabel(gbc, 0);
		panel1.add(kontoStand, gbc);

		kontoStandText1 = getKontostandText(0.00, gbc, 0);
		panel1.add(kontoStandText1, gbc);

		einzahlen1 = getEinzahlButton(gbc, 4);
		auszahlen1 = getAuszahlButton(gbc, 1);
		zahlung1 = getZahlFeld(gbc, 1);
		panel1.add(einzahlen1);
		panel1.add(auszahlen1);
		panel1.add(zahlung1, gbc);
		setConstraints(gbc, 0, 2, false);

		setConstraints(gbc, 0, true, 1);
		this.getContentPane().add(panel1, gbc);

		panel2 = new JPanel();
		panel2.setLayout(new GridBagLayout());
		panel2.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.BLACK, Color.BLACK));
		panel2.setPreferredSize(new Dimension(1000, 500));
		iban2 = getIbanLabel("LEER", gbc, 0);

		panel2.add(iban2, gbc);

		gbc.gridwidth = 1;

		kontoStand = getKontostandLabel(gbc, 1);
		panel2.add(kontoStand, gbc);

		kontoStandText2 = getKontostandText(0.00, gbc, 1);
		panel2.add(kontoStandText2, gbc);

		einzahlen2 = getEinzahlButton(gbc, 2);
		auszahlen2 = getAuszahlButton(gbc, 1);
		zahlung2 = getZahlFeld(gbc, 1);
		panel2.add(einzahlen2);
		panel2.add(auszahlen2);
		panel2.add(zahlung2, gbc);

		setConstraints(gbc, 1, 2, false);

		setConstraints(gbc, 1, true, 1);
		this.getContentPane().add(panel2, gbc);

		panel3 = new JPanel();
		panel3.setLayout(new GridBagLayout());
		panel3.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.BLACK, Color.BLACK));
		panel3.setPreferredSize(new Dimension(1000, 500));
		iban3 = getIbanLabel("LEER", gbc, 0);

		panel3.add(iban3, gbc);

		gbc.gridwidth = 1;

		kontoStand = getKontostandLabel(gbc, 1);
		panel3.add(kontoStand, gbc);

		kontoStandText3 = getKontostandText(0.00, gbc, 1);
		panel3.add(kontoStandText3, gbc);

		einzahlen3 = getEinzahlButton(gbc, 1);
		auszahlen3 = getAuszahlButton(gbc, 1);
		zahlung3 = getZahlFeld(gbc, 1);
		panel3.add(einzahlen3);
		panel3.add(auszahlen3);
		panel3.add(zahlung3, gbc);

		setConstraints(gbc, 2, 2, false);

		setConstraints(gbc, 2, true, 1);
		this.getContentPane().add(panel3, gbc);

		einzahlen1.addActionListener(this);
		einzahlen2.addActionListener(this);
		einzahlen3.addActionListener(this);
		auszahlen1.addActionListener(this);
		auszahlen2.addActionListener(this);
		auszahlen3.addActionListener(this);
	}

	/**
	 * Aktualisierung des unteren Bereichs des GUI-Fensters.
	 */
	public void updateBottomFrame() {
		int i = 0;
		GridBagConstraints gbc = new GridBagConstraints();
		for (Konto konto : konten) {
			this.setBottomFrame();
			System.out.println(this.iban1.getText());
			if (i == 0) {
				iban1.setText(konto.getIBAN());
				kontoStandText1.setText("" + konto.getKontostand() + " Euro");
			}
			if (i == 1) {
				iban2.setText(konto.getIBAN());
				kontoStandText2.setText("" + konto.getKontostand() + " Euro");
			}
			if (i == 2) {
				iban3.setText(konto.getIBAN());
				kontoStandText3.setText("" + konto.getKontostand() + " Euro");
			}
			i++;
		}
	}

	/**
	 * Button für das Einzahlen.
	 * 
	 * @param gbc
	 * @param horizontalAddition
	 * @return einzahlen Button Einzahlen
	 */
	private JButton getEinzahlButton(GridBagConstraints gbc, int horizontalAddition) {
		JButton einzahlen = new JButton("Einzahlen");
		einzahlen.setFont(new Font("Tahoma", Font.PLAIN, 14));
		einzahlen.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.GREEN, Color.GREEN));
		return einzahlen;
	}

	/**
	 * Button für das Auzahlen.
	 * 
	 * @param gbc
	 * @param horizontalAddition
	 * @return auszahlen Button Auszahlen
	 */
	private JButton getAuszahlButton(GridBagConstraints gbc, int horizontalAddition) {
		JButton auszahlen = new JButton("Auszahlen");
		auszahlen.setFont(new Font("Tahoma", Font.PLAIN, 14));
		auszahlen.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.RED, Color.RED));
		setConstraints(gbc, 2 + horizontalAddition, true, 1);
		return auszahlen;
	}

	/**
	 * Feld für den Ein-/Auszahlungsbetrag.
	 * 
	 * @param gbc
	 * @param horizontalAddition
	 * @return zahlung1
	 */
	private JTextField getZahlFeld(GridBagConstraints gbc, int horizontalAddition) {
		JTextField zahlung1 = new JTextField("Ein-/Auszahlungsbetrag");
		zahlung1.setFont(new Font("Tahoma", Font.PLAIN, 16));
		zahlung1.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.BLACK, Color.BLACK));
		zahlung1.setPreferredSize(new Dimension(30, 100));
		setConstraints(gbc, 2 + horizontalAddition, true, 1);
		return zahlung1;
	}

	/**
	 * Label für den aktuellen Kontostand in Euro.
	 * 
	 * @param kontostand
	 * @param gbc
	 * @param horizontalAddition
	 * @return
	 */
	private JLabel getKontostandText(double kontostand, GridBagConstraints gbc, int horizontalAddition) {
		JLabel kontoStandText = new JLabel();
		kontoStandText.setFont(new Font("Tahoma", Font.PLAIN, 16));
		kontoStandText.setText("" + kontostand + " Euro");
		kontoStandText.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.BLACK, Color.BLACK));
		kontoStandText.setPreferredSize(new Dimension(30, 100));
		setConstraints(gbc, 1 + horizontalAddition, true, 1);
		return kontoStandText;
	}

	/**
	 * Label "Kontostand".
	 * 
	 * @param gbc
	 * @param horizontalAddition
	 * @return
	 */
	private JLabel getKontostandLabel(GridBagConstraints gbc, int horizontalAddition) {
		kontoStand = new JLabel("Kontostand");
		kontoStand.setFont(new Font("Tahoma", Font.PLAIN, 16));
		kontoStand.setPreferredSize(new Dimension(5, 100));
		kontoStand.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED, Color.BLACK, Color.BLACK));
		setConstraints(gbc, 0 + horizontalAddition, true, 1);
		return kontoStand;
	}

	/**
	 * Label für die IBAN.
	 * 
	 * @param number
	 * @param gbc
	 * @param horizontalAddition
	 * @return
	 */
	private JLabel getIbanLabel(String number, GridBagConstraints gbc, int horizontalAddition) {
		JLabel iban = new JLabel(number);
		iban.setFont(new Font("Tahoma", Font.PLAIN, 20));
		iban.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED, Color.gray, Color.gray));
		gbc.gridwidth = 4;
		setConstraints(gbc, 0 + horizontalAddition, true, 0);
		return iban;
	}

	public Bank getBank() {
		return bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}

	public void setKonten(ArrayList<Konto> konten) {
		this.konten = konten;
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource() == this.auswahl) {
			int i = 0;
			String selected = box.getSelectedItem().toString();
			Kunde kunde = bank.getKundenByName(selected);
			this.setKonten(kunde.getKonten());

			iban1.setText("LEER");
			kontoStandText1.setText("" + 0.00 + " Euro");
			iban2.setText("LEER");
			kontoStandText2.setText("" + 0.00 + " Euro");
			iban3.setText("LEER");
			kontoStandText3.setText("" + 0.00 + " Euro");
			for (Konto konto : konten) {
				if (i == 0) {
					konto1 = konto;
					iban1.setText(konto.getIBAN());
					kontoStandText1.setText("" + konto.getKontostand());
				}else if(i == 1) {
					konto2 = konto;
					iban2.setText(konto.getIBAN());
					kontoStandText2.setText("" + konto.getKontostand());
				}else if (i == 2) {
					konto3 = konto;
					iban3.setText(konto.getIBAN());
					kontoStandText3.setText("" + konto.getKontostand());
				}
				i++;
			}
			double gesamtdepot = 0.0;
			for (Konto konto : konten) {
				gesamtdepot = gesamtdepot + konto.getKontostand();
			}
			textArea.setText("Gesamtdepot: " + gesamtdepot);
			textArea.setFont(new Font("Tahoma", Font.PLAIN, 14));
			this.setVisible(false);
			this.setVisible(true);
		}
		if (event.getSource() == this.info) {
			JOptionPane.showMessageDialog(null, "Carmen Luu, s0564264");
		}
		if (event.getSource() == this.einzahlen1) {
			String iban = konto1.getIBAN();
			double geldbetrag = Double.valueOf(zahlung1.getText());
			bank.geldEinzahlung(iban, geldbetrag);
			double neu = geldbetrag + Double.valueOf(kontoStandText1.getText());
			double gesamtdepot = 0.0;
			for (Konto konto : konten) {
				gesamtdepot = gesamtdepot + konto.getKontostand();
			}
			konto1.setKontostand(neu);
			kontoStandText1.setText("" + neu);
			textArea.setFont(new Font("Tahoma", Font.PLAIN, 14));
			textArea.setText(textArea.getText() + "\nEine EINZAHLUNG in Höhe von " + zahlung1.getText()
					+ "€ hat auf dem Konto " + iban + " stattgefunden. Neues Gesamtdepot: " + gesamtdepot
					+ "€\n______________________________________________________________________________________________________________");
		}
		if (event.getSource() == this.einzahlen2) {
			String iban = konto2.getIBAN();
			double geldbetrag = Double.valueOf(zahlung2.getText());
			bank.geldEinzahlung(iban, geldbetrag);
			double neu = geldbetrag + Double.valueOf(kontoStandText2.getText());
			double gesamtdepot = 0.0;
			for (Konto konto : konten) {
				gesamtdepot = gesamtdepot + konto.getKontostand();
			}
			konto2.setKontostand(neu);
			kontoStandText2.setText("" + neu);
			textArea.setText(textArea.getText() + "\nEine EINZAHLUNG in Höhe von " + zahlung2.getText()
					+ "€ hat auf dem Konto " + iban + " stattgefunden. Neues Gesamtdepot: " + gesamtdepot
					+ "€\n______________________________________________________________________________________________________________");
		}
		if (event.getSource() == this.einzahlen3) {
			String iban = konto3.getIBAN();
			double geldbetrag = Double.valueOf(zahlung3.getText());
			bank.geldEinzahlung(iban, geldbetrag);
			double neu = geldbetrag + Double.valueOf(kontoStandText3.getText());
			double gesamtdepot = 0.0;
			for (Konto konto : konten) {
				gesamtdepot = gesamtdepot + konto.getKontostand();
			}
			konto3.setKontostand(neu);
			kontoStandText3.setText("" + neu);
			textArea.setText(textArea.getText() + "\nEine EINZAHLUNG in Höhe von " + zahlung3.getText()
					+ "€ hat auf dem Konto " + iban + " stattgefunden. Neues Gesamtdepot: " + gesamtdepot
					+ "€\n______________________________________________________________________________________________________________");
		}
		if (event.getSource() == this.auszahlen1) {
			String iban = konto1.getIBAN();
			double geldbetrag = Double.valueOf(zahlung1.getText());
			bank.geldAuszahlung(iban, geldbetrag);
			double neu = Double.valueOf(kontoStandText1.getText()) - geldbetrag;
			double gesamtdepot = 0.0;
			for (Konto konto : konten) {
				gesamtdepot = gesamtdepot + konto.getKontostand();
			}
			konto1.setKontostand(neu);
			kontoStandText1.setText("" + neu);
			textArea.setText(textArea.getText() + "\nEine AUSZAHLUNG in Höhe von " + zahlung1.getText()
					+ "€ hat auf dem Konto " + iban + " stattgefunden. Neues Gesamtdepot: " + gesamtdepot
					+ "€\n______________________________________________________________________________________________________________");
		}
		if (event.getSource() == this.auszahlen2) {
			String iban = konto2.getIBAN();
			double geldbetrag = Double.valueOf(zahlung2.getText());
			bank.geldAuszahlung(iban, geldbetrag);
			double neu = Double.valueOf(kontoStandText2.getText()) - geldbetrag;
			double gesamtdepot = 0.0;
			for (Konto konto : konten) {
				gesamtdepot = gesamtdepot + konto.getKontostand();
			}
			konto2.setKontostand(neu);
			kontoStandText2.setText("" + neu);
			textArea.setText(textArea.getText() + "\nEine AUSZAHLUNG in Höhe von " + zahlung2.getText()
					+ "€ hat auf dem Konto " + iban + " stattgefunden. Neues Gesamtdepot: " + gesamtdepot
					+ "€\n______________________________________________________________________________________________________________");
		}
		if (event.getSource() == this.auszahlen3) {
			String iban = konto3.getIBAN();
			double geldbetrag = Double.valueOf(zahlung3.getText());
			bank.geldAuszahlung(iban, geldbetrag);
			double neu = Double.valueOf(kontoStandText3.getText()) - geldbetrag;
			double gesamtdepot = 0.0;
			for (Konto konto : konten) {
				gesamtdepot = gesamtdepot + konto.getKontostand();
			}
			konto3.setKontostand(neu);
			kontoStandText3.setText("" + neu);
			textArea.setText(textArea.getText() + "\nEine AUSZAHLUNG in Höhe von " + zahlung3.getText()
					+ "€ hat auf dem Konto " + iban + " stattgefunden. Neues Gesamtdepot: " + gesamtdepot
					+ "€\n______________________________________________________________________________________________________________");
		}
	}
}
