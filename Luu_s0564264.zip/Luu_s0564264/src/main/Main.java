package main;

import java.io.Serializable;

import bank.Bank;
import io.MenuEingabe;

/**
 * 
 * @author s0564264 Carmen Luu (s0564264@htw-berlin.de)
 *
 */

public class Main implements Serializable {
	public static void main(String[] args) {
		Bank bank = new Bank("Postbank Berlin", "Mariendorfer Damm", "422", 12107, "Berlin", 10010010, "PBNKDEFF");
		MenuEingabe menu = new MenuEingabe();

		menu.start(bank);
	}
}
