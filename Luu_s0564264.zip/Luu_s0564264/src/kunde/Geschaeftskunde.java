package kunde;

import java.io.Serializable;

/**
 * Kontruktor der Klasse Geschaefskunden mit den Parametern kundennr, firmenname,
 * adresszeile1, adresszeile2, PLZ, ort, telefonnr, emailadresse, anzahlKonten; 
 * setter und getter von: firmenname
 * 
 * @author s0564264 Carmen Luu (s0564264@htw-berlin.de)
 *
 */

public class Geschaeftskunde extends Kunde implements Serializable {
	/**
	 * Firmenname des Geschaeftskunden.
	 */
	private String firmenname;

	/**
	 * Kontruktor der Klasse Geschaefskunden mit den Parametern kundennr,
	 * firmenname, adresszeile1, adresszeile2, PLZ, ort, telefonnr, emailadresse,
	 * anzahlKonten.
	 * 
	 * @param kundennr
	 *            Kundennr des Geschaefskunden
	 * @param firmenname
	 *            Firmenname des Geschaefskunden
	 * @param adresszeile1
	 *            Adresszeile1 des Geschaefskunden
	 * @param adresszeile2
	 *            Adresszeile2 des Geschaefskunden
	 * @param PLZ
	 *            PLZ des Geschaefskunden
	 * @param ort
	 *            Ort des Geschaefskunden
	 * @param telefonnr
	 *            Telefonnr des Geschaefskunden
	 * @param emailadresse
	 *            E-Mail-Adresse des Geschaefskunden
	 * @param anzahlKonten
	 *            Anzahl der Konten des Geschaefskunden
	 */
	public Geschaeftskunde(int kundennr, String firmenname, String adresszeile1, String adresszeile2, int PLZ,
			String ort, String telefonnr, String emailadresse, int anzahlKonten) {
		super(kundennr, adresszeile1, adresszeile2, PLZ, ort, telefonnr, emailadresse, anzahlKonten);
		this.firmenname = firmenname;
	}

	public String getFirmenname() {
		return firmenname;
	}

	public void setFirmenname(String firmenname) {
		this.firmenname = firmenname;
	}

	@Override
	public String toString() {
		return "______________________________________________________________________________________________________________________________"
				+ "\nKundennr: " + this.getKundennr() + "\nAnzahl der Konten: " + this.getMaxKonten()
				+ "\n______________________________________________________________________________________________________________________________"
				+ "\nFirmenname: " + this.firmenname
				+ "\n______________________________________________________________________________________________________________________________"
				+ "\nAdresse: " + this.getAdresse().getAdresszeile1() + " " + this.getAdresse().getAdresszeile2()
				+ "	PLZ: " + this.getAdresse().getPLZ() + "	 	  Ort: " + this.getAdresse().getOrt()
				+ "\n______________________________________________________________________________________________________________________________"
				+ "\nTelefonnr: " + this.getTelefonnr() + "	 	E-Mail-Adresse: " + this.getEmailadresse()
				+ "\n______________________________________________________________________________________________________________________________\n";
	}

	@Override
	public String getName() {
		return this.firmenname;
	}
}
