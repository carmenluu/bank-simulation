package kunde;

import java.io.Serializable;

import io.Ausgabe;

/**
 * Kontruktor der Klasse Privatkunde mit den Parametern kundennr, anrede,
 * vorname, nachname, geburtsdatum, adresszeile1, adresszeile2, PLZ, ort,
 * telefonnr, emailadresse, anzahlKonten. 
 * setter und getter von: anrede, vorname, nachname, geburtsdatum
 * 
 * @author s0564264 Carmen Luu (s0564264@htw-berlin.de)
 *
 */

public class Privatkunde extends Kunde implements Serializable {
	/**
	 * Die Anrede des Privatkunden.
	 */
	private Anrede anrede;

	/**
	 * Der Vorname des Privatkunden.
	 */
	private String vorname;

	/**
	 * Der Nachname des Privatkunden.
	 */
	private String nachname;

	/**
	 * Das Geburtsdatum des Privatkunden.
	 */
	private String geburtsdatum;
	
	/**
	 * Objekt von der Klasse Ausgabe.
	 */
	Ausgabe ausgabe = new Ausgabe();

	/**
	 * Kontruktor der Klasse Privatkunde mit den Parametern kundennr, anrede,
	 * vorname, nachname, geburtsdatum, adresszeile1, adresszeile2, PLZ, ort,
	 * telefonnr, emailadresse, anzahlKonten.
	 * 
	 * @param kundennr
	 *            Kundennr des Privatkunden
	 * @param anrede
	 *            Anrede des Privatkunden
	 * @param vorname
	 *            Vorname des Privatkunden
	 * @param nachname
	 *            Nachname des Privatkunden
	 * @param geburtsdatum
	 *            Geburtsdatum des Privatkunden
	 * @param adresszeile1
	 *            Adresszeile1 des Privatkunden
	 * @param adresszeile2
	 *            Adresszeile2 des Privatkunden
	 * @param PLZ
	 *            PLZ des Privatkunden
	 * @param ort
	 *            Ort des Privatkunden
	 * @param telefonnr
	 *            Telefonnr des Privatkunden
	 * @param emailadresse
	 *            E-Mail-Adresse des Privatkunden
	 * @param anzahlKonten
	 *            Anzahl der Konten des Privatkunden
	 */
	public Privatkunde(int kundennr, String anrede, String vorname, String nachname, String geburtsdatum,
			String adresszeile1, String adresszeile2, int PLZ, String ort, String telefonnr, String emailadresse,
			int anzahlKonten) {
		super(kundennr, adresszeile1, adresszeile2, PLZ, ort, telefonnr, emailadresse, anzahlKonten);
		this.setAnrede(anrede);
		this.vorname = vorname;
		this.nachname = nachname;
		this.geburtsdatum = geburtsdatum;
	}

	public Anrede getAnrede() {
		return anrede;
	}

	public void setAnrede(String anrede) {
		try {
			if (anrede.equals("Herr") || anrede.equals("herr") || anrede.equals("HERR")) {
				this.anrede = Anrede.HERR;
			} else if (anrede.equals("Frau") || anrede.equals("frau") || anrede.equals("FRAU")) {
				this.anrede = Anrede.FRAU;
			}
		} catch (Exception e) {
			ausgabe.falscheAnrede();
		}
	}

	public String getVorname() {
		return vorname;
	}

	public void setVorname(String vorname) {
		this.vorname = vorname;
	}

	public String getNachname() {
		return nachname;
	}

	public void setNachname(String nachname) {
		this.nachname = nachname;
	}

	public String getGeburtsdatum() {
		return geburtsdatum;
	}

	public void setGeburtsdatum(String geburtsdatum) {
		this.geburtsdatum = geburtsdatum;
	}

	@Override
	public String toString() {
		return "______________________________________________________________________________________________________________________________"
				+ "\nKundennr: " + this.getKundennr() + "\nAnzahl der Konten: " + this.getMaxKonten()
				+ "\n______________________________________________________________________________________________________________________________"
				+ "\nAnrede: " + this.anrede + "			Nachname: " + this.nachname + "		  Vorname: "
				+ this.vorname + "		Geburtsdatum: " + this.geburtsdatum
				+ "\n______________________________________________________________________________________________________________________________"
				+ "\nAdresse: " + this.getAdresse().getAdresszeile1() + " " + this.getAdresse().getAdresszeile2()
				+ "	PLZ: " + this.getAdresse().getPLZ() + "	 	  Ort: " + this.getAdresse().getOrt()
				+ "\n______________________________________________________________________________________________________________________________"
				+ "\nTelefonnr: " + this.getTelefonnr() + "	 	E-Mail-Adresse: " + this.getEmailadresse()
				+ "\n______________________________________________________________________________________________________________________________\n";
	}

	@Override
	public String getName() {
		return this.nachname + " " + this.vorname;
	}
}
