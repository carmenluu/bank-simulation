package kunde;

import java.io.Serializable;
import java.util.ArrayList;
import adresse.Adresse;
import bank.Konto;
import io.Ausgabe;

/**
 * Kontruktor der Klasse Kunde mit den Parametern kundennr, adresszeile1,
 * adresszeile2, PLZ, ort, telefonnr, emailadresse, anzahlKonten; 
 * Legt das Maximum der Anzahl der Konten des Kunden fest. Fuegt ein Konto dem Konto-Array
 * hinzu. Gibt die Konten aus. Zaehlt die Konten des Kunden. 
 * setter und getter von: kundennr, adresse, telefonnr, emailadresse, konten, maxKonten
 * abtract String getName()
 * 
 * @author s0564264 Carmen Luu (s0564264@htw-berlin.de)
 *
 */

public abstract class Kunde implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Die Kundennummer des Kunden.
	 */
	private int kundennr;

	/**
	 * Die Adresse des Kunden.
	 */
	private Adresse adresse;

	/**
	 * Die Telefonnummer des Kunden.
	 */
	private String telefonnr;

	/**
	 * Die E-Mail-Adresse des Kunden.
	 */
	private String emailadresse;

	/**
	 * Die Konten des Kunden bei der Bank.
	 */
	private ArrayList<Konto> konten = new ArrayList<>();

	/**
	 * Objekt von der Klasse Ausgabe.
	 */
	Ausgabe ausgabe = new Ausgabe();

	/**
	 * Maximale Konten des Kunden.
	 */
	private int maxkonten;
	
	/**
	 * Kontruktor der Klasse Kunde mit den Parametern kundennr, adresszeile1,
	 * adresszeile2, PLZ, ort, telefonnr, emailadresse, anzahlKonten.
	 * 
	 * @param kundennr
	 *            Kundennummer des Kunden
	 * @param adresszeile1
	 *            Adresszeile1 des Kunden
	 * @param adresszeile2
	 *            Adresszeile2 des Kunden
	 * @param PLZ
	 *            PLZ des Kunden
	 * @param ort
	 *            Ort des Kunden
	 * @param telefonnr
	 *            Telefonnummer des Kunden
	 * @param emailadresse
	 *            E-Mail-Adresse des Kunden
	 * @param anzahlKonten
	 *            Anzahl der Konten des Kunden
	 */
	public Kunde(int kundennr, String adresszeile1, String adresszeile2, int PLZ, String ort, String telefonnr,
			String emailadresse, int anzahlKonten) {
		this.kundennr = kundennr;
		this.adresse = new Adresse(adresszeile1, adresszeile2, PLZ, ort);
		this.telefonnr = telefonnr;
		this.emailadresse = emailadresse;
		this.maxkonten = anzahlKonten;
	}

	/**
	 * Legt das Maximum der Anzahl der Konten des Kunden fest.
	 * 
	 * @param anzahlKonten
	 *            Anzahl der maximalen Konten des Kunden
	 */
	public void makeKonten(int anzahlKonten) {
		if (anzahlKonten > 10) {
			ausgabe.printZuVieleKonten();
			throw new IndexOutOfBoundsException();
		} else {
			maxkonten = anzahlKonten;
		}
	}

	/**
	 * Fuegt ein Konto dem Konto-Array hinzu.
	 * 
	 * @param konto
	 *            Konto des Kunden
	 */
	public void addKonto(Konto konto) {
		if (konten.size() <= maxkonten) {
			konten.add(konto);
		} else {
			ausgabe.falscheKontenAnzahl();
			throw new IndexOutOfBoundsException();
		}
	}

	/**
	 * Gibt die Konten aus.
	 */
	public void printKonto() {
		for (int i = 0; i < konten.size(); i++) {
			System.out.println(konten.get(i).toString());
		}
	}

	/**
	 * Zaehlt die Konten des Kunden.
	 * 
	 * @return counter Zaehler
	 */
	public int countKonto() {
		int counter = 0;
		for (int i = 0; i < konten.size(); i++) {
			if (konten.get(i) != null) {
				counter++;
			}
		}
		return counter;
	}

	public int getKundennr() {
		return kundennr;
	}

	public void setKundennr(int kundennr) {
		this.kundennr = kundennr;
	}

	public Adresse getAdresse() {
		return adresse;
	}

	public void setAdresse(Adresse adresse) {
		this.adresse = adresse;
	}

	public String getTelefonnr() {
		return telefonnr;
	}

	public void setTelefonnr(String telefonnr) {
		this.telefonnr = telefonnr;
	}

	public String getEmailadresse() {
		return emailadresse;
	}

	public void setEmailadresse(String emailadresse) {
		this.emailadresse = emailadresse;
	}

	public ArrayList<Konto> getKonten() {
		return konten;
	}
	
	public void setKonten(ArrayList<Konto> konten) {
		this.konten = konten;
	}

	public int getMaxKonten() {
		return maxkonten;
	}

	public void setMaxkonten(int konten) {
		this.maxkonten = konten;
	}

	public abstract String getName();

}
