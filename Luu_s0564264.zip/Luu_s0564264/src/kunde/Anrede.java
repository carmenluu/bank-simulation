package kunde;

import java.io.Serializable;

/**
 * Gibt die moeglichen Anredeformen an.
 * 
 * @author s0564264 Carmen Luu (s0564264@htw-berlin.de)
 *
 */

public enum Anrede implements Serializable {
	/**
	 * Moegliche Anredeformen.
	 */
	HERR, FRAU;
}
